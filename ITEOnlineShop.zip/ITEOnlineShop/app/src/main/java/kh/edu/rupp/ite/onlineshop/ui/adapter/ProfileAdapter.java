package kh.edu.rupp.ite.onlineshop.ui.adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import kh.edu.rupp.ite.onlineshop.api.model.Profile;
import kh.edu.rupp.ite.onlineshop.databinding.ViewHolderProfileBinding;

public class ProfileAdapter extends ListAdapter<Profile, ProfileAdapter.ProfileViewHolder> {

    public ProfileAdapter() {
        super(new DiffUtil.ItemCallback<Profile>() {
            @Override
            public boolean areItemsTheSame(@NonNull Profile oldItem, @NonNull Profile newItem) {
                return oldItem == newItem;
            }

            @Override
            public boolean areContentsTheSame(@NonNull Profile oldItem, @NonNull Profile newItem) {
                return true;
            }
        });
    }

    @NonNull
    @Override
    public ProfileViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        ViewHolderProfileBinding binding = ViewHolderProfileBinding.inflate(layoutInflater, parent, false);
        ProfileAdapter.ProfileViewHolder viewHolder = new ProfileViewHolder(binding);
        return new ProfileViewHolder(binding);

    }

    @Override
    public void onBindViewHolder(@NonNull ProfileAdapter.ProfileViewHolder holder, int position) {
        Profile item = getItem(position);
        holder.bind(item);
    }

    public static class ProfileViewHolder extends RecyclerView.ViewHolder {
        private final ViewHolderProfileBinding itemBinding;

        public ProfileViewHolder(ViewHolderProfileBinding itemBinding) {
            super(itemBinding.getRoot());
            this.itemBinding = itemBinding;
        }

        public void bind(Profile profile){
            Picasso.get().load(profile.getImageUrl()).into(itemBinding.imgProfile);
            itemBinding.txtFirstName.setText(profile.getFirst_name());
            itemBinding.txtLastName.setText(profile.getLast_name());
            itemBinding.txtEmail.setText(profile.getEmail());
            itemBinding.txtPhone.setText(profile.getPhoneNumber());
            itemBinding.textEmail.setText(profile.getEmail());
            itemBinding.txtGender.setText(profile.getGender());
            itemBinding.txtBirthday.setText(profile.getBirthday());
            itemBinding.txtAddress.setText(profile.getAddress());
        }
    }
}
