package kh.edu.rupp.ite.onlineshop.ui.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import kh.edu.rupp.ite.onlineshop.databinding.FragmentProductBinding;
import kh.edu.rupp.ite.onlineshop.databinding.FragmentProfileBinding;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import java.util.Collections;
import java.util.List;

import kh.edu.rupp.ite.onlineshop.api.model.Profile;
import kh.edu.rupp.ite.onlineshop.api.service.ApiService;
import kh.edu.rupp.ite.onlineshop.databinding.FragmentProfileBinding;

import kh.edu.rupp.ite.onlineshop.ui.adapter.ProfileAdapter;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ProfileFragment extends Fragment {

    private FragmentProfileBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        binding = FragmentProfileBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        LoadProfileListFromServer();
    }

    private void LoadProfileListFromServer() {
        Retrofit httpClient = new Retrofit.Builder()
                .baseUrl("https://raw.githubusercontent.com/kimsongsao/ferupp/main/profile.json/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        //Create service object
        ApiService apiService = httpClient.create(ApiService.class);

        //load province list from server
        Call<Profile> task = apiService.LoadProfileData();
        task.enqueue(new Callback<Profile>() {
            @Override
            public void onResponse(@NonNull Call<Profile> call, @NonNull Response<Profile> response) {
                if(response.isSuccessful()){
                    showProfileList(response.body());
                }else{
                    Toast.makeText(getContext(), "Load Profile Data failed!", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(@NonNull Call<Profile> call, @NonNull Throwable t) {
                Toast.makeText(getContext(), "Load Profile Data failed!", Toast.LENGTH_LONG).show();
                Log.e("[ProfileFragment]", "Load profile failed: " + t.getMessage());
                t.printStackTrace();
            }
        });
    }

    private void showProfileList(Profile profileList){

        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        binding.recyclerViews.setLayoutManager(layoutManager);

        ProfileAdapter adapter = new ProfileAdapter();
        adapter.submitList(Collections.singletonList(profileList));
        binding.recyclerViews.setAdapter(adapter);

    }
}
